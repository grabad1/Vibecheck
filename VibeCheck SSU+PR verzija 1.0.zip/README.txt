Prototip se pokreće dvoklikom na index.html stranicu. 
Kredencijali za admina: username = admin, password = 123;
Kredencijali za moderatora: username = moderator, password = 123;
Kredencijali za usera: bilo koji unos;